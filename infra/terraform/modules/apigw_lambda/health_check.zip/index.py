import json
import time

def handler(event, context):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'status': 'healthy',
            'timestamp': time.time(),
            'service': 'kidjamo-health-check',
            'environment': 'dev',
            'message': 'Infrastructure is running'
        })
    }
